# JQC: Java Quantum Computing

## JQC Syntax:
- One-line commands
- Not case-specific
- Whitespace-specific
- Command template: [Action] [Type] [Target] *[Optional: 2nd target]* 
- Structure like verbal English commands: "Do this action to that type's target *[Optional: to this other target]*"