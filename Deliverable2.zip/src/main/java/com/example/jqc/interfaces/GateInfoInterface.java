package com.example.jqc.interfaces;

public interface GateInfoInterface {
    String getGateId();
    void setGateId(String x);
    String toString();
}
